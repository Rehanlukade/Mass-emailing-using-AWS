export interface EmailObj {
    id: string
    createdAt: string
    email: string
}
